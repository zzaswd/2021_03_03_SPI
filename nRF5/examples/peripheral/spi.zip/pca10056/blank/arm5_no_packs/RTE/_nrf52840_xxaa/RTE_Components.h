
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'spi_pca10056' 
 * Target:  'nrf52840_xxaa' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "nrf.h"



#endif /* RTE_COMPONENTS_H */
